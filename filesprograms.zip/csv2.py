


import csv
 
ids= []
name = []
 
with open('D:\\empdb.csv') as csvDataFile:
    csvReader = csv.reader(csvDataFile)
    for row in csvReader:
        ids.append(row[0])
        name.append(row[1])
 
print(ids)
print(name)
