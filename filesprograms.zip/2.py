#write a program that reads a file line by line
#each line read from the file is copied to another file with line numbers
#specified at the beginning of the line.
f1=open("D:\\ab.txt","r")
f2=open("D:\\my.txt","w")
num=1
for line in f1:
    f2.write(str(num)+":"+line)
    num=num+1
f1.close()
f2.close()
