


import csv

with open('D:\\empdb.csv', mode='w') as employee_file:
    employee_writer = csv.writer(employee_file, delimiter=',', quotechar='"')

    employee_writer.writerow([503,'John Smith', 25000,'Accounting', '02/02/1998'])
    employee_writer.writerow([504,'Erica Meyers',15000, 'IT', '05/08/2008'])
