with open("D:\\ab.txt","rb") as f:
	for line in f:
		print(line)
print("file closed",f.close())
