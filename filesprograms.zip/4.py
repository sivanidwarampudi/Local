#program to read a file and captialize the first letter
#of every word
fname = input("Enter file name: ")
with open(fname, 'r') as f:
    for line in f:
        l=line.title()
        print(l)
