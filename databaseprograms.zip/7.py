


import sqlite3

conn = sqlite3.connect('D:\\ds.db')
cur = conn.cursor()
cur.execute('SELECT * from empdb')
print(cur.fetchall())
